﻿using Microsoft.AspNetCore.Mvc;
using reportplusback.Data;
using reportplusback.Models;
using System.Linq;

namespace reportplusback.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TaskController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TaskController(AppDbContext context)
        {
            _context = context;
        }

        // Obter todas as tarefas
        [HttpGet]
        public IActionResult GetTasks()
        {
            var userIdClaim = User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return Unauthorized("Usuário não autenticado.");
            }

            int userId = int.Parse(userIdClaim.Value); // Obtém o ID do usuário logado
            var tasks = _context.Tasks.Where(t => t.UserId == userId).ToList();
            return Ok(tasks);
        }

        [HttpPost]
        public IActionResult CreateTask([FromBody] TaskModel task)
        {
            var userIdClaim = User.FindFirst("UserId");
            if (userIdClaim == null)
            {
                return Unauthorized("Usuário não autenticado.");
            }

            int userId = int.Parse(userIdClaim.Value); // Obtém o ID do usuário logado
            task.UserId = userId; // Associa a tarefa ao usuário logado

            _context.Tasks.Add(task);
            _context.SaveChanges();
            return CreatedAtAction(nameof(GetTasks), new { id = task.Id }, task);
        }



        // Atualizar uma tarefa
        [HttpPut("{id}")]
        public IActionResult UpdateTask(int id, [FromBody] TaskModel updatedTask)
        {
            var task = _context.Tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound("Tarefa não encontrada");

            task.Title = updatedTask.Title;
            task.Description = updatedTask.Description;
            task.Completed = updatedTask.Completed;
            task.UpdatedAt = DateTime.Now;

            _context.SaveChanges();
            return Ok(task);
        }

        // Excluir uma tarefa
        [HttpDelete("{id}")]
        public IActionResult DeleteTask(int id)
        {
            var task = _context.Tasks.FirstOrDefault(t => t.Id == id);
            if (task == null) return NotFound("Tarefa não encontrada");

            _context.Tasks.Remove(task);
            _context.SaveChanges();
            return NoContent();
        }
    }
}
