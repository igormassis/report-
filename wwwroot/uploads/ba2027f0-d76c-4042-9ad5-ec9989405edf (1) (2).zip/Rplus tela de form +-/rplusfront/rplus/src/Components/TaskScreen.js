import React, { useState, useEffect } from "react";
import axios from "axios";
import TaskHeader from "../headers/TaskHeader"; // Importando o TaskHeader

const TaskScreen = () => {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);

  // Carregar tarefas do backend
  useEffect(() => {
    const fetchTasks = async () => {
      try {
        console.log("Iniciando requisição para tarefas...");
        const userId = localStorage.getItem("userId");
  
        if (!userId) {
          console.error("Usuário não logado ou ID não encontrado.");
          return;
        }
  
        // Requisição ao backend para buscar as tarefas do usuário logado
        const response = await axios.get(`/api/tasks?userId=${userId}`);
        console.log("Tarefas recebidas:", response.data);
        setTasks(response.data);
        setLoading(false);
      } catch (error) {
        console.error("Erro ao buscar tarefas:", error);
        setLoading(false);
      }
    };
  
    fetchTasks();
  }, []);
  

  // Adicionar uma nova tarefa
  const handleAddTask = async () => {
    const title = prompt("Digite o título da nova tarefa:");
    if (!title) return;

    try {
      // Recupera o ID do usuário logado do localStorage
      const userId = localStorage.getItem("userId");
      if (!userId) {
        console.error("Usuário não logado ou ID não encontrado.");
        return;
      }

      // Cria a tarefa associada ao usuário logado
      const response = await axios.post("/api/tasks", {
        title,
        completed: false,
        userId, // Envia o ID do usuário
      });
      setTasks((prevTasks) => [...prevTasks, response.data]);
    } catch (error) {
      console.error("Erro ao adicionar tarefa:", error);
    }
  };

  // Alternar status de conclusão de uma tarefa
  const handleToggleTask = async (id, completed) => {
    try {
      const response = await axios.put(`/api/tasks/${id}`, { completed: !completed });
      setTasks((prevTasks) =>
        prevTasks.map((task) => (task.id === id ? response.data : task))
      );
    } catch (error) {
      console.error("Erro ao alterar status da tarefa:", error);
    }
  };

  // Excluir uma tarefa
  const handleDeleteTask = async (id) => {
    if (!window.confirm("Tem certeza que deseja excluir esta tarefa?")) return;

    try {
      await axios.delete(`/api/tasks/${id}`);
      setTasks((prevTasks) => prevTasks.filter((task) => task.id !== id));
    } catch (error) {
      console.error("Erro ao excluir tarefa:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen bg-gradient-to-br from-indigo-100 to-indigo-300">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-blue-500"></div>
          <p className="mt-4 text-lg font-medium text-gray-700">Carregando tarefas...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Adicionando o TaskHeader */}
      <TaskHeader
        user={{ name: "Usuário Logado" }} // Exemplo, pode ser substituído pelo estado real do usuário
        onLogout={() => {
          localStorage.removeItem("userId");
          console.log("Usuário deslogado.");
        }}
      />
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 to-indigo-300 py-10 px-6">
        <div className="max-w-4xl mx-auto bg-white shadow-2xl rounded-lg p-8">
          <h1 className="text-4xl font-extrabold text-center text-indigo-600 mb-8">
            Gerenciador de Tarefas
          </h1>
          <div className="flex justify-center mb-6">
            <button
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-8 rounded-full shadow-lg transition duration-300 transform hover:scale-105"
              onClick={handleAddTask}
            >
              + Adicionar Tarefa
            </button>
          </div>
          <div className="space-y-6">
            {tasks.length === 0 ? (
              <p className="text-center text-gray-500 text-lg">
                Nenhuma tarefa encontrada. Clique em "Adicionar Tarefa" para começar!
              </p>
            ) : (
              tasks.map((task) => (
                <div
                  key={task.id}
                  className={`flex items-center justify-between p-6 rounded-xl shadow-lg transition duration-300 ${
                    task.completed
                      ? "bg-gradient-to-r from-green-100 to-green-300"
                      : "bg-gradient-to-r from-gray-100 to-gray-200 hover:bg-gradient-to-l"
                  }`}
                >
                  <div>
                    <h2
                      className={`text-2xl font-bold ${
                        task.completed ? "text-green-800 line-through" : "text-gray-800"
                      }`}
                    >
                      {task.title}
                    </h2>
                    <p className="text-sm text-gray-600">
                      {task.completed ? "Concluída" : "Pendente"}
                    </p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <button
                      className={`py-2 px-6 rounded-full font-medium transition duration-300 transform hover:scale-105 ${
                        task.completed
                          ? "bg-yellow-400 hover:bg-yellow-500 text-white"
                          : "bg-green-500 hover:bg-green-600 text-white"
                      }`}
                      onClick={() => handleToggleTask(task.id, task.completed)}
                    >
                      {task.completed ? "Reabrir" : "Concluir"}
                    </button>
                    <button
                      className="bg-red-500 hover:bg-red-600 text-white py-2 px-6 rounded-full transition duration-300 transform hover:scale-105 shadow-md"
                      onClick={() => handleDeleteTask(task.id)}
                    >
                      Excluir
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskScreen;
