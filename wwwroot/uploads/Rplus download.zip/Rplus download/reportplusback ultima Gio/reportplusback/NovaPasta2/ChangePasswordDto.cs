﻿namespace reportplusback.NovaPasta2
{
    public class ChangePasswordDto
    {
    }
}
