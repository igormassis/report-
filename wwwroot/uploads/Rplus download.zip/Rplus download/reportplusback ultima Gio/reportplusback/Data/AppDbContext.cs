﻿using Microsoft.EntityFrameworkCore;
using reportplusback.Models;

namespace reportplusback.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; } = null!;
        public DbSet<FormModel> Forms { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<FormModel>()
                .Property(f => f.FilePath)
                .HasMaxLength(255)
                .IsRequired(false);

            modelBuilder.Entity<FormModel>()
                .HasOne(f => f.User)
                .WithMany(u => u.Forms)
                .HasForeignKey(f => f.UserId);
        }

    }
}