import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../../lib/utils";

const FormDetails = () => {
    const { id } = useParams();
    const [form, setForm] = useState(null);
    const [error, setError] = useState("");
    const [downloadError, setDownloadError] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        const fetchFormDetails = async () => {
            try {
                const response = await api.get(`/form/${id}`);
                setForm(response.data);
            } catch (error) {
                console.error("Erro ao buscar o formulário:", error);
                setError("Erro ao carregar os detalhes do formulário.");
            }
        };

        fetchFormDetails();
    }, [id]);

    const handleDownload = async (fileName) => {
        try {
            console.log("Baixando arquivo:", fileName);

            if (!fileName || typeof fileName !== "string") {
                console.error("Nome do arquivo inválido:", fileName);
                setDownloadError("Nome do arquivo inválido.");
                return;
            }

            const response = await api.get(`/form/download/${encodeURIComponent(fileName)}`, {
                responseType: "blob",
            });

            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement("a");
            link.href = url;
            link.setAttribute("download", fileName);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

            setDownloadError("");
        } catch (error) {
            console.error("Erro ao baixar o arquivo:", error);
            setDownloadError("Erro ao baixar o arquivo. Tente novamente.");
        }
    };

    if (error) {
        return (
            <div className="min-h-screen bg-gradient-to-b from-blue-100 to-blue-300 flex justify-center items-center">
                <div className="bg-white p-8 rounded-xl shadow-lg text-center">
                    <p className="text-red-500 font-bold text-lg">{error}</p>
                    <button
                        onClick={() => navigate("/home")}
                        className="mt-4 bg-blue-600 text-white px-4 py-2 rounded"
                    >
                        Voltar para a Home
                    </button>
                </div>
            </div>
        );
    }

    if (!form) {
        return (
            <div className="min-h-screen bg-gradient-to-b from-blue-100 to-blue-300 flex justify-center items-center">
                <p className="text-lg font-semibold text-gray-600">Carregando...</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-b from-blue-100 to-blue-300">
            <main className="container mx-auto py-12 px-8">
                <button
                    onClick={() => navigate("/home")}
                    className="bg-blue-600 text-white px-4 py-2 rounded mb-4"
                >
                    Voltar para a Home
                </button>

                <div className="bg-white p-10 rounded-xl shadow-lg">
                    <h1 className="text-4xl font-extrabold text-gray-800">{form.title}</h1>
                    <p className="text-lg text-gray-600 mt-4">{form.description}</p>

                    <div className="mt-4">
                        {downloadError && (
                            <p className="text-red-500 font-semibold">{downloadError}</p>
                        )}
                        <button
                            onClick={() => handleDownload(form.fileName)}
                            className="bg-blue-600 text-white px-4 py-2 rounded"
                        >
                            Baixar Arquivo
                        </button>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default FormDetails;
